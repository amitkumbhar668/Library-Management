from django.urls import path
from . import views
from .views import BookList,BookCreate,BookDelete,BookUpdate,BookDetail

urlpatterns = [
    path('import-books/', views.import_books, name='import_books'),
    path('', BookList.as_view(), name='list'),  #homepage
    path('create/', BookCreate.as_view(), name='create'),
    path('delete/<int:pk>/', BookDelete.as_view(), name='delete'),
    path('update/<int:pk>/', BookUpdate.as_view(), name='update'),
    path('details/<int:pk>/', BookDetail.as_view(), name='details'),


]
